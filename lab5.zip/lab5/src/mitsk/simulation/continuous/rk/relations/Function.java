package mitsk.simulation.continuous.rk.relations;

public abstract class Function {
    public Function(){

    }
    public abstract double getValue(double x, double y);
}
