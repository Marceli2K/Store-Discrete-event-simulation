package mitsk.generators;

public interface Generator {
    public double getNext() throws InterruptedException;

}
